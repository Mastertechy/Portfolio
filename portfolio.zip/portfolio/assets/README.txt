Images, audio, video, and the favicon for the site are stored in this folder.
